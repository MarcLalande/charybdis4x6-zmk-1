# S40NC
![S40NC](https://i.imgur.com/fk8587n.jpg)

Shorty40NoCordy (S40NC) is a limited run 40% bluetooth keyboard originally made and sold by MechWild.

## Building S40NC ZMK firmware
```
west build -p -b s40nc
```
