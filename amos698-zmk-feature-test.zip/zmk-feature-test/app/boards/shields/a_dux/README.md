# A. Dux

Shield configuration for [Architeuthis Dux by Tapi][1] (aka A. Dux, A.D., "Giant Squid").

![Wireless Architeuthis Dux with nice!nano controllers][2]

This shield is an adaptation of the direct pin [Cradio shield by @davidphilipbarr][3].

## Cephalopoda

Check out the rest of Tapi's Cephalopoda collection of low profile split ergonomic mechanical keyboards at <https://github.com/tapioki/cephalopoda>.

[1]: https://github.com/tapioki/cephalopoda/tree/main/Architeuthis%20dux
[2]: https://media.discordapp.net/attachments/855822038287908864/866315666802081792/image0.jpg
[3]: https://github.com/zmkfirmware/zmk/tree/main/app/boards/shields/cradio
