# The Clog

The Clog is a 34-key choc v1 split board by S'mores. This firmware works for both the [Clog][clog],
as well as the [Sephirette][sephirette], the MX version. You can purchase kits for both boards
at smoresboards.com.

[clog]: https://github.com/smores56/clog
[sephirette]: https://github.com/smores56/sephirette
