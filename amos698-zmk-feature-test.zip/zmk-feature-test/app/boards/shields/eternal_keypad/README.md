# Eternal Keypad

Eternal Keypad is an open-source input device for gaming that can be assembled for both right and left hand mouse users.

Firmware is described in the [Eternal Keypad](https://github.com/duckyb/eternal-keypad) repository [README](https://github.com/duckyb/eternal-keypad#firmware).

Two keymaps are included:

- eternal_keypad (default)
- eternal_keypad_lefty (for left handed users)
