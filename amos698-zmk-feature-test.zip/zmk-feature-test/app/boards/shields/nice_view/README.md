# nice!view

The nice!view is a low power, high refresh rate display meant to replace I2C OLEDs traditionally used.

This shield requires that an `&nice_view_spi` labelled SPI bus is provided with *at least* MOSI, SCK, and CS pins defined.
