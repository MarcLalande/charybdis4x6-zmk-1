/*
 * Copyright (c) 2020 The ZMK Contributors
 *
 * SPDX-License-Identifier: MIT
 */

#warning "kscan-mock.h has been deprecated and superseded by kscan_mock.h"

#include "kscan_mock.h"